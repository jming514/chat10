/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat10;

import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Earvin
 */
public class loginDBTest {
    
    public loginDBTest() {
    }
    
  
    @Test
    public void testConnect() {
        System.out.println("connect");
        try{
        loginDB.connect();
        }
        catch(Exception e){
            System.out.println("Failure");
        }
    }

    /**
     * Test of createNewTable method, of class loginDB.
     */
    @Test
    public void testCreateNewTable() {
        System.out.println("createNewTable");
        try{
        loginDB.createNewTable();
        }
        catch(Exception e){
            System.out.println("Failure");
        }

    }

    /**
     * Test of selectAll method, of class loginDB.
     */
    @Test
    public void testSelectAll() {
        System.out.println("selectAll");
        try{
        loginDB instance = new loginDB();
        instance.selectAll();
        }
        catch(Exception e){
            System.out.println("Failure");
        }

    }

    /**
     * Test of Frame method, of class loginDB.
     */
    @Test
    public void testFrame() {
        System.out.println("Frame");
        try{
        loginDB instance = new loginDB();
        instance.Frame();
        }
        catch(Exception e){
            System.out.println("Failure");
        }

    }

    /**
     * Test of main method, of class loginDB.
     */
    @Test
    public void testMain() throws Exception {
        System.out.println("main");
        String[] args = null;
        try{
        loginDB.main(args);        
        }
        catch(Exception e){
            System.out.println("Failure");
        }

    }
    
}
