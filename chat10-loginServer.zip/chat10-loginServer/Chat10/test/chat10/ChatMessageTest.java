/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat10;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class ChatMessageTest {
    private ChatMessage messagetest;
    
    public ChatMessageTest() {
        messagetest = new ChatMessage(1, "Hello");
        assertEquals(1, ChatMessage.MESSAGE);
        assertEquals("Hello", messagetest.getMessage());
    }
    
    @Test
    public void testGetType() {
        System.out.println("getType");
        ChatMessage instance = new ChatMessage(1, "Hello");
        assertEquals(instance.getType(), 1);

    }

    @Test
    public void testGetMessage() {
        System.out.println("getMessage");
        ChatMessage instance = new ChatMessage(1, "Hello");
        String result = instance.getMessage();
        assertEquals("Hello", result);

    }
}



