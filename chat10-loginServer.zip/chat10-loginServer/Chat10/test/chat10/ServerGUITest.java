/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat10;

import java.awt.event.ActionEvent;
import java.awt.event.WindowEvent;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/**
 *
 * @author Earvin
 */
public class ServerGUITest {
    
    public ServerGUITest() {
    }
    
    @Test
    public void testAppendRoom() {
        System.out.println("appendRoom");
        String str = "";
        ServerGUI instance = new ServerGUI(1);
        instance.appendRoom(str);
    }

    /**
     * Test of appendEvent method, of class ServerGUI.
     */
    @Test
    public void testAppendEvent() {
        System.out.println("appendEvent");
        String str = "";
        ServerGUI instance = new ServerGUI(1);
        instance.appendEvent(str);
    }

    /**
     * Test of actionPerformed method, of class ServerGUI.
     */
    @Test
    public void testActionPerformed() {
        System.out.println("actionPerformed");
        ActionEvent e = null;
        ServerGUI instance = new ServerGUI(1);
        instance.actionPerformed(e);
    }

    /**
     * Test of main method, of class ServerGUI.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] arg = null;
        ServerGUI.main(arg);
    }

    /**
     * Test of windowClosing method, of class ServerGUI.
     */
    @Test
    public void testWindowClosing() {
        System.out.println("windowClosing");
        WindowEvent e = null;
        ServerGUI instance = new ServerGUI(1);
        instance.windowClosing(e);
    }

    /**
     * Test of windowClosed method, of class ServerGUI.
     */
    @Test
    public void testWindowClosed() {
        System.out.println("windowClosed");
        WindowEvent e = null;
        ServerGUI instance = new ServerGUI(1);
        instance.windowClosed(e);
    }

    /**
     * Test of windowOpened method, of class ServerGUI.
     */
    @Test
    public void testWindowOpened() {
        System.out.println("windowOpened");
        WindowEvent e = null;
        ServerGUI instance = new ServerGUI(1);
        instance.windowOpened(e);
    }

    /**
     * Test of windowIconified method, of class ServerGUI.
     */
    @Test
    public void testWindowIconified() {
        System.out.println("windowIconified");
        WindowEvent e = null;
        ServerGUI instance = new ServerGUI(1);
        instance.windowIconified(e);
    }

    /**
     * Test of windowDeiconified method, of class ServerGUI.
     */
    @Test
    public void testWindowDeiconified() {
        System.out.println("windowDeiconified");
        WindowEvent e = null;
        ServerGUI instance = new ServerGUI(1);
        instance.windowDeiconified(e);
    }

    /**
     * Test of windowActivated method, of class ServerGUI.
     */
    @Test
    public void testWindowActivated() {
        System.out.println("windowActivated");
        WindowEvent e = null;
        ServerGUI instance = new ServerGUI(1);
        instance.windowActivated(e);
    }

    /**
     * Test of windowDeactivated method, of class ServerGUI.
     */
    @Test
    public void testWindowDeactivated() {
        System.out.println("windowDeactivated");
        WindowEvent e = null;
        ServerGUI instance = new ServerGUI(1);
        instance.windowDeactivated(e);
    }
    
}
