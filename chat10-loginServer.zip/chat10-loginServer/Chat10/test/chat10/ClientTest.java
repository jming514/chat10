/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat10;

import java.io.*;
import java.net.*;
import java.util.*;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Earvin
 */
public class ClientTest {
    private Client clienttest;
   
    public ClientTest() {
        clienttest = new Client("Server1", 1,"Bob");
        
    }
    
    @Test
    public void testStart() {
        System.out.println("start");
        clienttest.start();
        boolean result = clienttest.start();
        assertEquals(1, result);
    }

    @Test
    public void testSendMessage() {
        System.out.println("sendMessage");
        ChatMessage msg = new ChatMessage(1,"Hello");
        clienttest.sendMessage(msg);
        
    }

    /**
     * Test of main method, of class Client.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        try{
        Client.main(args);
        }
        catch(Exception e){
            System.out.println("Failure");
        }
    }
}

