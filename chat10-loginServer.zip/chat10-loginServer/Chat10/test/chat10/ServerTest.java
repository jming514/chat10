/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat10;

import java.io.*;
import java.net.*;
import java.util.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Date;
import org.junit.After;
import org.junit.Before;


/**
 *
 * @author Earvin
 */
public class ServerTest {
    
    private Server servertest;
    private int port;
    
    public ServerTest() {
        servertest = new Server(2, null);
    }
    
    @Test
    public void testStart() {
        System.out.println("start");
        servertest.start();
        try{
        ServerSocket serverSocket = new ServerSocket(port);
        }
        catch(IOException e){
            
        }
    }

    /**
     * Test of stop method, of class Server.
     */
    @Test
    public void testStop() {
        System.out.println("stop");
        try{
        Socket a = new Socket("localhost", port);
        Socket b = new Socket("", 0);
        b.getLocalAddress();
        assertEquals(b,a);
        }
        catch (IOException e){
           System.out.println("Failure"); 
        } 
        
    }
        
    

    /**
     * Test of remove method, of class Server.
     */
    @Test
    public void testRemove() {
        System.out.println("remove");
        try{
        ServerSocket serverSocket = new ServerSocket(port);
        servertest.remove(port);
        }
        catch (Exception e){
            System.out.println("Failure");
        } 
    }

    /**
     * Test of main method, of class Server.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null; 
        try{
        Server.main(args);
        } 
        catch(Exception e){
            System.out.println("Failure");
        }
            

        
    }
    
}

